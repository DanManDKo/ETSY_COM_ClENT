package com.example.user.etsyclient.db;

/**
 * Created by User on 03.01.2017.
 */

public class CacheManager {
}
